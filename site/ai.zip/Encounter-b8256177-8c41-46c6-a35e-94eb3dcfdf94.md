# b8256177-8c41-46c6-a35e-94eb3dcfdf94 - Arbeitsgruppe WeST v1.0.0-kommentierung

Arbeitsgruppe WeST

Version 1.0.0-kommentierung - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **b8256177-8c41-46c6-a35e-94eb3dcfdf94**

## Example Encounter: b8256177-8c41-46c6-a35e-94eb3dcfdf94



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "b8256177-8c41-46c6-a35e-94eb3dcfdf94",
  "meta" : {
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_WEST_Encounter|1.0.0-kommentierung"]
  },
  "status" : "planned",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "AMB"
  },
  "subject" : {
    "reference" : "Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d"
  },
  "participant" : [{
    "individual" : {
      "reference" : "urn:uuid:9df81f65-7b3c-410b-b8f1-6426649fcde4"
    }
  }],
  "period" : {
    "start" : "2021-11-15"
  },
  "serviceProvider" : {
    "reference" : "urn:uuid:1e02c811-9ac0-4120-b8b7-58538c6d549f"
  }
}

```
