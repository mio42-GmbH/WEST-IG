# Datenmodell - Arbeitsgruppe WeST v1.0.0-kommentierung

Arbeitsgruppe WeST

Version 1.0.0-kommentierung - ci-build 

* [**Table of Contents**](toc.md)
* **Datenmodell**

## Datenmodell

 Erläuterungen zum Informationsmodell 

###### Erläuterungen zum Informationsmodell allgemein

Auf dieser Seite werden die medizinisch-fachlichen Inhalte der Wechselschnittstelle in Form eines hierarchischen Informationsmodells dargestellt. Dieses soll dem Fachpublikum eine Übersicht über die Inhalte der Spezifikation bieten und stellt gleichzeitig im Rahmen der Entwicklung eine wichtige Grundlage für die Erstellung der technischen Spezifikation dar.

Die einzelnen Elemente des Informationsmodells enthalten bestimmte Informationen, die hier kurz erläutert werden (Hinweis: nicht jedes Element enthält alle hier aufgeführten Informationen):

| | |
| :--- | :--- |
| **Name/Beschreibung:** | benennt das Element und beschreibt, mit welchem Inhalt es befüllt wird |
| **Rationale:** | enthält eine Begründung, warum das Element in der vorliegenden Form in das Informationsmodell aufgenommen wurde, z.B. durch Referenzen auf externe Spezifikationen |
| **Datentyp:** | gibt den Datentyp an, mit dem das Element befüllt wird (siehe auch:[https://hl7.org/fhir/datatypes.html](https://hl7.org/fhir/datatypes.html)) |
| **Kardinalität:** | gibt an, wie häufig in einem bestimmten Anwendungsszenario ein Wert für das Element übermittelt werden darf - ausgedrückt mittels eines* minimalen und eines* maximalen Wertes (siehe auch[https://www.hl7.org/fhir/conformance-rules.html#cardinality](https://www.hl7.org/fhir/conformance-rules.html#cardinality)) sowie eine* der folgenden Konformitäten:* Mandatory (M) = es **muss **(mindestens) ein gültiger Wert im Element vorliegen
* Required (R) = es **soll **(mindestens) ein gültiger Wert im Element vorliegen
* Optional (O) = es **kann **(mindestens) ein gültiger Wert vorliegen
* Not present (NP) = es **darf kein** Wert vorliegen
***Hinweis: es können in seltenen Fällen auch mehrere Kardinalitäten/Konformitäten in Abhängigkeit von definierten Bedingungen an einem Element angegeben sein** |
| **Terminologie-Assoziation / Wertelisten:** | enthält einzelne oder mehrere Codes, mit denen dieses Element gefüllt werden kann bzw. muss |
| **Operationalisierungshinweis:** | Hinweis zur Umsetzung des Elements in Primärsystemen (**“kann”**- oder “**sollte**“-Hinweis) |
| **Vorgabe:** | Vorgabe zur Umsetzung des Elements in Primärsystemen (“**muss**“-Hinweis) |
| **FHIR-Mappings:** | gibt an, an welcher Stelle in der technischen FHIR®-Spezifikation das Element umgesetzt ist |
| **(spezifische) Eigenschaften:** | enthält über die oben aufgeführten Informationen hinausgehende spezifische Informationen |

**Erläuterungen zum Informationsmodell der Wechselschnittstelle**

###### Grundstruktur des Informationsmodells der Wechselschnittstelle

Das Informationsmodell der Wechselschnittstelle ist in mehrere Arbeitspakete gegliedert und verschachtelt strukturiert. Die detailliertere Zuweisung von Kardinalitäten und Konformitäten der einzelnen Elemente des Informationsmodells kann in den Details der jeweiligen Elemente eingesehen werden.

**Details**

**Name:**

**Beschreibung:**

**Rationale:**

**Datentyp:**

**Kardinalität:**

**Operationalisierungshinweis:**

**Terminologie Assoziationen:**

**Wertelisten:**

**FHIR Mappings:**

 Szenario: Arbeitspaket 1 

* Name: ARBEITSPAKET-1
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:   Patient:in
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Identifikator
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       VersichertenID
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: identifier
* Name:       Versichertennummer_KVK
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: identifier
* Name:       Versichertennummer_PKV
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: identifier
* Name:       PID
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: identifier
* Name:     Name
  * Kardinalität: 1..*
  * Konformität: M
  * Datentyp: 
* Name:       Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Vorsatzwort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Namenszusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Titel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Nachname
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:         Vorname
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Anschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Straßenanschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Anschriftenzusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Postfach
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Postfach
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Geburtsdatum
  * Kardinalität: Bedingung
* Name: 1..1Normalerweise sollte das Datum immer angegeben werden
  * Kardinalität: M
  * Konformität: date
* Name: 0..1In nicht abschließend definierten Ausnahmen ist eine Nichtangabe erlaubt.
  * Kardinalität: O
  * Konformität: date
* Name:     Administratives Geschlecht
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Kontaktdaten
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Kontaktkanal
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Sprache
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:     Foto
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: complex
* Name:     Tätigkeit
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       Bezeichnung
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: string
* Name:       Arbeitgeber
  * Kardinalität: 0..*
  * Konformität: R
  * Datentyp: 
* Name:         Referenz Arbeitgeber
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:           NOT_FOUND
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:         Arbeitgeber des Patienten mit Adresse des Arbeitgebers
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:       Beschäftig seit
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: datetime
* Name:     Hausarzt
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       Referenz Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:         NOT_FOUND
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Staatsangehörigkeit
  * Kardinalität: 0..*
  * Konformität: R
  * Datentyp: code
* Name:     Versichertendaten
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Vorsatzwort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Namenszusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Titel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Nachname
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Vorname
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Administratives Geschlecht
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Geburtsdatum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: date
* Name:       Anschrift
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Straßenanschrift
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Anschriftenzusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Stadtteil
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Postfach
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Postfach
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Stadtteil
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:   Behandelnde Person
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Identifikator
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       ANR
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: identifier
* Name:       Vertragspartner-ID
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Typ
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Typ
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         ID
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Name
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Vorsatzwort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Namenszusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Titel
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: string
* Name:         Nachname
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:         Vorname
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Anschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Straßenanschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Geburtsdatum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: date
* Name:     Administratives Geschlecht
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Kontaktdaten
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Kontaktkanal
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Ergänzende Angaben
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Anrede/Briefanrede/Briefschluss
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Briefanrede
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Schlusssatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:   Behandelnde Person/Einrichtung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Referenz Einrichtung/Organisationseinheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:     Referenz Behandelnde Person
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:     Fachrichtung - Code/Bezeichnung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         KBV-Fachgruppencodierung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:   Einrichtung/Organisationseinheit
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Identifikator
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       VKNR
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: identifier
* Name:       HzV-Kassen-Kürzel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       KZV-Abrechnungsnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: identifier
* Name:       IK-Nummer
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: identifier
* Name:       BSNR
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: identifier
* Name:     Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Übergeordnete Einrichtung/Organisationseinheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Einrichtung/Organisationseinheit
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: reference
* Name:     Anschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Straßenanschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Vertretung (Referenz)
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:       Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:     Spezieller Kontakt
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Kontaktdaten
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Adresse
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Kontaktkanal
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Kontaktangaben
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Wert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Zweck
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Organisationskontaktdaten
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Kontaktkanal
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Ergänzende Angaben
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:   Betriebsstätte
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Identifikator
  * Kardinalität: 1..*
  * Konformität: M
  * Datentyp: 
* Name:       IK-Nummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: identifier
* Name:       BSNR
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: identifier
* Name:     Typ - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Status der Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Anschrift
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Straßenanschrift
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Postfach
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Postfach
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Kontaktdaten
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Kontaktkanal
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Wert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Ergänzende Angaben
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: count

 Szenario: Arbeitspaket 2 

* Name: ARBEITSPAKET-2
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:   Arzneimittel-Information
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Arzneimittel/Rezeptur - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         PZN
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Preisinformation
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Preistyp
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Preis
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Betrag
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: decimal
* Name:         Währung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Indikation Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         ICD-10 Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Nebenwirkungen
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Nebenwirkungen Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Wechselwirkungen
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Strukturierte Wechselwirkungserfassung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Beschreibung der Wechselwirkung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Wechselwirkende Substanz / Arzneimittel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz Arzneimittel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Arzneimittel
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: reference
* Name:           Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:               PZN
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:               SNOMED-CT
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:             Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Wechselwirkungen Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Gegenanzeige Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         ICD-10 Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Hinweise
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Alternativen
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Alternative Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Arzneimittel-Information
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:       Alternative Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:   Arzneimittel
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Typ
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Status
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Arzneimittel/Rezeptur - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         PZN
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         ATC-Code Deutsch
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         SNOMED CT®-Code
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Darreichungsform - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         SNOMED CT®-Code
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         EDQM
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         KBV Darreichungsform
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Packungsgröße/Gesamtmenge
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Anzahl/Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Wert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:         Einheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Anzahl/Menge der Bezugsgröße
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Wert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:         Einheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Packungsgröße nach N-Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Bestandteile
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Ist Wirkstoff
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: boolean
* Name:       Referenziertes Arzneimittel
  * Kardinalität: Bedingung
* Name: 1..1Angabe als Referenz
  * Kardinalität: M
  * Konformität: 
* Name: 0..0Angabe codiert
  * Kardinalität: NP
  * Konformität: 
* Name:         Referenz
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Bestandteil - Code/Bezeichnung
  * Kardinalität: Bedingung
* Name: 1..1Angabe Codiert
  * Kardinalität: M
  * Konformität: 
* Name: 0..0Angabe als Referenz
  * Kardinalität: NP
  * Konformität: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           ASK-Code
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Menge/Stärke
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Anzahl/Menge des enthaltenen Bestandteils
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Wert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:           Einheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Anzahl/Menge der Bezugsgröße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Wert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:           Einheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Chargennummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Haltbarkeitsdatum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: date
* Name:   Medikations-Information
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Arzneimittel
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Referenz
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Arzneimittel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Statusgrund - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code aus einem Codesystem
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Datum/Zeit der Informationserfassung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:     Verabreichung/Einnahme: Zeitangabe-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Zeitpunkt
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:       Zeitraum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         von
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         bis
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:     Dosierung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Dosierung der einzelnen Verabreichung/Einnahme
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Menge pro Gabe/Einnahme
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Feste Menge pro Gabe/Einnahme
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Dosiereinheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Mengenbereich pro Gabe/Einnahme
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Obergrenze
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:               Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Dosiereinheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             Untergrenze
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:               Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Dosiereinheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Rate/Verabreichungsgeschwindigkeit-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Feste Rate/Verabreichungsgeschwindigkeit mit kombinierter Einheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Kombinierte Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Feste Rate/Verabreichungsgeschwindigkeit mit Angabe von Zähler/Nenner
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Zähler Verabreichungsgeschwindigkeit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:               Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Dosiereinheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             Nenner Verabreichungsgeschwindigkeit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:               Wert der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Einheit der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Bereich für Rate/Verabreichungsgeschwindigkeit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Obergrenze: Verabreichungsgeschwindigkeit mit kombinierter Einheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:               Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Kombinierte Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             Untergrenze: Verabreichungsgeschwindigkeit mit kombinierter Einheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:               Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Kombinierte Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Dauer der einzelnen Verabreichung/Einnahme
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Wert der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:           Maximaler Wert der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:           Einheit der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Verabreichungsweg - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:             SNOMED CT®-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:             EDQM-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:             Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:             Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Wiederholung der Verabreichung/Einnahme
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Zeitangabe-Auswahl (dosisspezifisch)
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Zeitraum (dosisspezifisch)
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             von
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:             bis
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:           Feste Zeitspanne (dosisspezifisch)
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Wert der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Variable Zeitspanne (dosisspezifisch)
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Obergrenze
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:               Wert der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Einheit der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             Untergrenze
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:               Wert der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:               Einheit der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Anzahl der Wiederholungen
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Absolute Anzahl der Wiederholungen
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: count
* Name:           Maximale Anzahl der Wiederholungen
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: count
* Name:         Frequenz/Zeitspanne der Wiederholungen
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Absolute Anzahl der Frequenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: count
* Name:           Maximale Anzahl der Frequenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: count
* Name:           Absoluter Wert der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:           Maximaler Wert der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: quantity
* Name:           Einheit der Zeitspanne
  * Kardinalität: Bedingung
* Name: 1..1wenn eine Dauer der Zeitspanne vorhanden ist
  * Kardinalität: M
  * Konformität: code
* Name: 0..0sonst
  * Kardinalität: NP
  * Konformität: code
* Name:         Uhrzeit
  * Kardinalität: Bedingung
* Name: 0..0wenn Tageszeit und/oder Mahlzeiten-/Schlafzeitenabhängige Zusatzinformation existiert
  * Kardinalität: NP
  * Konformität: quantity
* Name: 0..*sonst
  * Kardinalität: O
  * Konformität: quantity
* Name:         Tageszeit/Zusatzinformationen
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Tageszeit
  * Kardinalität: Bedingung
* Name: 0..0wenn Uhrzeit existiert
  * Kardinalität: NP
  * Konformität: code
* Name: 0..*sonst
  * Kardinalität: O
  * Konformität: code
* Name:           Mahlzeiten-/Schlafzeitenabhängige Zusatzinformation
  * Kardinalität: Bedingung
* Name: 0..0wenn Uhrzeit existiert
  * Kardinalität: NP
  * Konformität: code
* Name: 0..*sonst
  * Kardinalität: O
  * Konformität: code
* Name:           Zeitabstand zu einer Mahlzeit/Schlafzeit
  * Kardinalität: Bedingung
* Name: 0..1wenn Mahlzeiten-/Schlafzeitenabhängige Zusatzinformation existiert UND als Code nicht "mit der Mahlzeit" ausgewählt ist
  * Kardinalität: O
  * Konformität: count
* Name: 0..0sonst
  * Kardinalität: NP
  * Konformität: count
* Name:         Wochentag
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bedarfsmedikation
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Bedarfsmedikation ja/nein
  * Kardinalität: Bedingung
* Name: 0..0wenn Bedingung vorhanden
  * Kardinalität: NP
  * Konformität: boolean
* Name: 0..1sonst
  * Kardinalität: O
  * Konformität: boolean
* Name:         Bedingung - Code/Bezeichnung
  * Kardinalität: Bedingung
* Name: 0..0wenn Bedarfsmedikation ja/nein ausgefüllt
  * Kardinalität: NP
  * Konformität: 
* Name: 0..1sonst
  * Kardinalität: O
  * Konformität: 
* Name:           Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:             SNOMED CT®-Code
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:             Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Maximale Menge pro Gabe/Einnahme
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:           Dosiereinheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Maximale Menge pro Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:             Wert der Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Dosiereinheit der Menge
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:             Wert der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit der Zeitspanne
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Bereich der Verabreichungsfrequenz (informativ)
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Frequenz/Zeitspanne der Wiederholungen
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:       Hinweise
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Freitext Dosieranweisung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:       Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:   Begegnung/Aufenthalt
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Schein-ID
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Setting - Code-Auswahl
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Erweiterbare Werteliste
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Verantwortliche Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:     Fachrichtung/Fachabteilung - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         KBV-Fachgruppencodierung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         HL7®-Fachabteilungsschlüssel
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         HL7®-Fachabteilungsschlüssel erweitert
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Grund
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Grund - Code/Bezeichnung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Referenz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Diagnose
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: reference
* Name:     Zeitangabe-Auswahl
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Zeitpunkt
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:       Zeitraum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         von
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         bis
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:     Beteiligte Personen
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Referenz auf Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:         Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:       Rolle
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:     Spezielle Begegnungsinformationen
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Typ
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Inhalt
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:   Diagnose
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Codierung Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 1..*
  * Konformität: M
  * Datentyp: 
* Name:         ICD-10-GM-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Diagnosecode
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Codierungskennzeichen
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:           ICD-Diagnosesicherheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:           ICD-Seitenlokalisation
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         ALPHA-ID-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         SNOMED CT®-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         ORPHANET-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Klinischer Status
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Diagnosesicherheit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Schweregrad
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code aus einem Codesystem
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Klinisch relevanter Zeitraum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       von
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Lebensphase
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Datum/Zeit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: date
* Name:         Alter
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:           Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Beginn der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:           Ende der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Altersspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Beginn der Altersspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Ende der Altersspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       bis
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Lebensphase
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Datum/Zeit
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: date
* Name:         Alter
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:           Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Beginn der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:           Ende der Zeitspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Altersspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Beginn der Altersspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Ende der Altersspanne
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Feststellungsdatum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: date
* Name:     Dokumentationsdatum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: date
* Name:     Diagnostizierende Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Referenz
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:         Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:     Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:           Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:         Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:       Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Ausnahmetatbestand
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Diagnosekategorien
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Abrechnungsrelevant
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: boolean
* Name:       Dauerdiagnose
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: boolean
* Name:       Diagnosenart
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:   Vitalzeichen und Körpermaße
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Bauchumfang
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code / Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Hüftumfang
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code / Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Atemfrequenz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Blutdruck
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       systolischer Blutdruck
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:           Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:             LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Messwert systolisch
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Systolischer Blutdruckwert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       diastolischer Blutdruck
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:           Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:             LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Messwert diastolisch
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Diastolischer Blutdruckwert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       mittlerer arterieller Blutdruck
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:           Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:             LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:             Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:           Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Messwert Mittelwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Mittlerer arterieller Blutdruckwert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Glukosespiegel
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 1..*
  * Konformität: M
  * Datentyp: 
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messergebnis Quantität
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:         Komparator
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Richtgrenzen
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Typ
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Obere Referenzgrenze
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:           Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Untere Referenzgrenze
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:           Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Interpretation - Code/Bezeichnung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           SNOMED CT-Code®
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Herzfrequenz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Kopfumfang
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           SNOMED CT®-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Körpergewicht
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           SNOMED CT®-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Körperlänge/Körpergröße
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Körpertemperatur
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     periphere arterielle Sauerstoffsättigung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:           LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           LOINC®-Zusatzcode
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:           Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Körperstelle - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Code aus einem Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Methode - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Messwert
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:       Zeitpunkt der Messung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: datetime
* Name:       Sauerstoffgabe
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Sauerstoff-Flussrate
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:             Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:               LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:               SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:               Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:             Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Messwert Flussrate
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         Sauerstoff-Konzentration
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:           Codierung - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:             Code-Auswahl
  * Kardinalität: 2..*
  * Konformität: M
  * Datentyp: 
* Name:               LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:               SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:               Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:             Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:           Messwert Konzentration
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:             Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: quantity
* Name:             Einheit
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Notiz
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Autor:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Zeitpunkt der Erstellung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         Text
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:   Behandlung im Auftrag Überweisung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Auftragsart
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Auftragsbeschreibung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Leistungsart
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Patient:in
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:     Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Begegnung/Aufenthalt
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:     Ausstellungsdatum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:     Erstveranlassende Überweisende Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Referenz Behandelnde Person / Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:       ANR
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: identifier
* Name:       Bezeichner
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Überweisung an
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:         Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:       Anzeigetext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Grund
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Freitext Diagnose/Verdachtsdiagnose
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Referenz Diagnose/Verdachtsdiagnose
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         Diagnose
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: reference
* Name:     Zusätzliche Informationen
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Befund Medikation
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Referenz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:           Arzneimittel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:           Medikations-Information
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:         Befund Medikation Freitext
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Ausnahmeindikation
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Ausnahmekennziffer
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Abrechnungsrelevant
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: boolean
* Name:   Anamnese
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:     Status
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 1..2
  * Konformität: M
  * Datentyp: 
* Name:         SNOMED CT®-Code
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:         LOINC®-Code
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Referenz Behandelnder/Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:     Referenz Begegnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Begegnung/Aufenthalt
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: reference
* Name:     Aufnahmezeitpunkt
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:     Beschreibung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string

 Szenario: Arbeitspaket 3 

* Name: ARBEITSPAKET-3
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:   Befund/Bericht
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Kategorie - Code/Bezeichnung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Diagnostic Service Section Codes
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Befund/Bericht - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Gesamtbeurteilung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Relevanter Zeitpunkt-/raum
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Zeitraum
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:         von
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:         bis
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:       Zeitpunkt
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:     Referenz Ergebnis
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Referenz Vitalzeichen und Körpermaße
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:         Vitalzeichen und Körpermaße
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: reference
* Name:     Referenz Durchführende Person
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Behandelnde Person
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: reference
* Name:     Referenz Dokument
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Dokumentenverweis/Anhang
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: reference
* Name:   Kontaktperson
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Beziehung - Code/Bezeichnung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Patient relationship type
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Administratives Geschlecht
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Vollständiger Name
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Vorsatzwort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Namenszusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Titel
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Nachname
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Vorname
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Anschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Straßenanschrift
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Anschriftenzusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Stadtteil
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Postfach
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Postfach
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Stadtteil
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:         Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Kontaktdaten
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Kontaktkanal
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Hinweis
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:   Dokumentenverweis/Anhang
  * Kardinalität: 0..*
  * Konformität: R
  * Datentyp: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:     Typ - Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         XDS
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         KBV
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Kategorie - Code/Bezeichnung
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Code-Auswahl
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         XDS
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Code aus einem anderen Codesystem
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:     Dokumentenverweis
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Name des Dokumentes
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:       URI des Dokuments
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Dokumentanhang
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Titel
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:       Dateiformat
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Datei
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: blob
* Name:     Zeitpunkt der Erstellung des Dokumentes
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:     Autor:in
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:     Beschreibung des Dokuments
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:   Herkunftsinformation
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Referenz auf das Ziel
  * Kardinalität: 1..*
  * Konformität: M
  * Datentyp: 
* Name:       Referenz
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:     Ursprungs-Information
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Art der Nutzung
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Verantwortliche Person/Entität
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:         Referenz auf Person/Entität
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:           Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:           Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:         Art der Beteiligung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:         Rolle der Person
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:       Referenz auf die Ursprungs-Information
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:         Referenz
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:     Beteiligte Person/Entität
  * Kardinalität: 1..*
  * Konformität: M
  * Datentyp: 
* Name:       Referenz auf Person/Entität
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: 
* Name:       Art der Beteiligung
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:       Rolle der Person/Entität
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: code
* Name:     Zeitpunkt der durchgeführten Aktivität
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: datetime
* Name:   Krankenversicherung
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:     Versichertennummer
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       VersichertenID_GKV
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: identifier
* Name:       Versichertennummer_KVK
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: identifier
* Name:       VersichertenID_PKV
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: identifier
* Name:       Versichertennummer_PKV
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: identifier
* Name:       VersichertenID_Pseudo
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: identifier
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: code
* Name:     Hauptversicherte Person
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       Referenz
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:         Kontaktperson
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:         Patient:in
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:       Versichertennummer
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:         Typ
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:         Wert
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: reference
* Name:     Zeitraum
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       von
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: date
* Name:       bis
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: date
* Name:     Kostenträger
  * Kardinalität: 2..3
  * Konformität: R
  * Datentyp: 
* Name:       Kostenträgertyp
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: code
* Name:       Referenz
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:         Einrichtung/Organisationseinheit
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:       Institutionskennzeichen
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: identifier
* Name:       Kostenträgername
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: string
* Name:     Einlesedatum
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: datetime
* Name:     Prüfnachweis
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       Prüfziffer
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:       Error-Code
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:       Ergebnis
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:       Datum
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: datetime
* Name:     Version-eGK
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:     Generation-eGK
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:     Versichertenart
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:     Kostenerstattung
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       Veranlasste Leistungen
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: boolean
* Name:       Stationärer Sektor
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: boolean
* Name:       Zahnärztlicher Sektor
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: boolean
* Name:       Ärztliche Sektor
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: boolean
* Name:     Wohnortprinzip
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:     Besondere Personengruppe
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:     DMP-Kennzeichen
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:     Ruhender Leistungsanspruch
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       Art
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: code
* Name:       Zeitraum
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:         von
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: date
* Name:         bis
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: date
* Name:     Zuzahlungsstatus
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: 
* Name:       Status
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: boolean
* Name:       Gültigkeitsende
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: date
* Name:     SKT-Zusatzangabe
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:   Mitarbeiter
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Mitarbeiternummer
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: string
* Name:     Name
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:       Vollständiger Name
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:       Vorsatzwort
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:       Namenszusatz
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:       Titel
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:       Nachname
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:       Vorname
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string
* Name:     Straßenanschrift
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Anschriftenzusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Stadtteil
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Kontaktdaten
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:       Kontaktkanal
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: code
* Name:       Wert
  * Kardinalität: 1..1
  * Konformität: M
  * Datentyp: string
* Name:     Administratives Geschlecht
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:   Hausbesuch
  * Kardinalität: 0..*
  * Konformität: O
  * Datentyp: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: code
* Name:     Klassifikation
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:       Patient:in
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:     Grund
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: complex
* Name:     Ort
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:       Ort Hausbesuch
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:       Entfernungsinformationen
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:         Zone Besuchsort
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: complex
* Name:         Einfache Entfernung
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: quantity
* Name:     Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:       Begegnung/Aufenthalt
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: reference
* Name:   Ort Hausbesuch
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: 
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: code
* Name:     Kontaktdaten
  * Kardinalität: 0..*
  * Konformität: R
  * Datentyp: 
* Name:       Kontaktkanal
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: code
* Name:       Wert
  * Kardinalität: 1..1
  * Konformität: R
  * Datentyp: string
* Name:     Straßenanschrift
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: 
* Name:       Straße
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Hausnummer
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Anschriftenzusatz
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Postleitzahl
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Ort
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: string
* Name:       Land/Wohnsitzländercode
  * Kardinalität: 0..1
  * Konformität: O
  * Datentyp: code
* Name:     Unstrukturierte Straßenanschrift
  * Kardinalität: 0..1
  * Konformität: R
  * Datentyp: string

 Szenario: Arbeitspaket 4 

* Name: ARBEITSPAKET-4
  * Kardinalität: 0..1
  * Konformität: 
* Name:   GKV-Abrechnung
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Nutzung
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Abrechnungsquartal
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Abrechnungsquartal Startdatum
  * Kardinalität: 1..1
  * Konformität: date
* Name:       Abrechnungsquartal Enddatum
  * Kardinalität: 1..1
  * Konformität: date
* Name:     Erstellt
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Referenz BehandelnderFunktion/Betriebsstätte
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Priorität
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Referenz Weiterbehandlung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Weiterbehandlung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Unterstützende Information
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Ringversuchszertifikat
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Referenz Ringversuchszertifikat
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Ringversuchszertifikat
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Leistungsgenehmigung
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Referenz Leistungsgenehmigungen
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Leistung_Psychotherapie
  * Kardinalität: 1..1
  * Konformität: reference
* Name:           Leistung_Heilmittel
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Zusatzinformationen
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Schein-ID
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Kostenträger-Abrechnungsbereich
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Abrechnungsgebiet
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Scheinuntergruppe
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Kennziffer SA
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Abklärung somatischer Ursachen vor Aufnahme einer Psychotherapie
  * Kardinalität: 0..1
  * Konformität: boolean
* Name:       Unfall/ Unfallfolge
  * Kardinalität: 0..1
  * Konformität: boolean
* Name:       anerkannte Psychotherapie
  * Kardinalität: 0..1
  * Konformität: boolean
* Name:       Zulassungsnummer
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Krankenversicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Krankenversicherungsverhältnis
  * Kardinalität: 1..1
  * Konformität: reference
* Name:   Materialien Sachen
  * Kardinalität: 1..1
  * Konformität: 
* Name:     Materialkode
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Name Hersteller
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Materialbezeichner
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Materialtyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Nummer
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Ablageort
  * Kardinalität: 1..1
  * Konformität: string
* Name:   Vorläufige Abrechnung
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Nutzung
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Erstellt
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Referenz Anbieter
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Priorität
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Abrechnungsposition
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Katalog
  * Kardinalität: 1..1
  * Konformität: 
* Name:         GOPs
  * Kardinalität: 0..1
  * Konformität: 
* Name:           bmae
  * Kardinalität: 0..1
  * Konformität: code
* Name:           e-go
  * Kardinalität: 0..1
  * Konformität: code
* Name:           ebm
  * Kardinalität: 0..1
  * Konformität: code
* Name:           goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:           uv-goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:           hzv_selektiv
  * Kardinalität: 0..1
  * Konformität: code
* Name:           sonstige_GOP
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Multiplikator
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Einzelbetrag
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Steigerungsfaktor
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Gesamtbetrag
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Begegnung/Aufenthalt
  * Kardinalität: 0..1
  * Konformität: reference
* Name:         Hausbesuch
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Material Sachkosten
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Referenz Materialien
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Materialien Sachen
  * Kardinalität: 1..1
  * Konformität: reference
* Name:         Betrag
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Spezielle Abrechnungsbegründung
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Untersuchungsart
  * Kardinalität: 0..1
  * Konformität: string
* Name:         Arztname
  * Kardinalität: 0..1
  * Konformität: string
* Name:         Leistungserbringung
  * Kardinalität: 0..1
  * Konformität: boolean
* Name:         Begründung
  * Kardinalität: 0..1
  * Konformität: string
* Name:         Prozentualer Leistungsanteil
  * Kardinalität: 0..1
  * Konformität: decimal
* Name:         Bezugsperson
  * Kardinalität: 0..1
  * Konformität: boolean
* Name:         Wiederholungsuntersuchung
  * Kardinalität: 0..1
  * Konformität: boolean
* Name:         Krebsfrüherkennung
  * Kardinalität: 0..1
  * Konformität: date
* Name:         Organbezug
  * Kardinalität: 0..1
  * Konformität: string
* Name:         GOP Zusatz
  * Kardinalität: 0..1
  * Konformität: string
* Name:         FEK Patientennummer
  * Kardinalität: 0..1
  * Konformität: string
* Name:         Patientennummer eDokumentation Hautkrebsscreening
  * Kardinalität: 0..1
  * Konformität: string
* Name:         ASV Teamnummer
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:         Kontrastmittel
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:         TSVG Vermittlungsart
  * Kardinalität: 0..1
  * Konformität: code
* Name:         Ergänzende Informationen zur Vermittlungs-/Kontaktart
  * Kardinalität: 0..1
  * Konformität: string
* Name:         TSVG Kontaktaufnahme
  * Kardinalität: 0..1
  * Konformität: date
* Name:         Vermittelnde behandelnde Person
  * Kardinalität: 0..1
  * Konformität: 
* Name:           Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Referenz genetische Untersuchung
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Genetische Untersuchung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Referenz ambulanten Operation
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Allgemeine Ambulante Operation
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Abrechnungsrelevant
  * Kardinalität: 1..1
  * Konformität: boolean
* Name:     Krankenversicherung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Krankenversicherungsverhältnis
  * Kardinalität: 0..1
  * Konformität: reference
* Name:   Privatabrechnung
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Rechnungsnummer
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Nummer
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Nutzung
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Abrechnungszeitraum
  * Kardinalität: 0..1
  * Konformität: 
* Name:       von
  * Kardinalität: 0..1
  * Konformität: date
* Name:       bis
  * Kardinalität: 0..1
  * Konformität: date
* Name:     Rechnungsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Abrechnungsdienst
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Referenz Organisation
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Einrichtung/Organisationseinheit
  * Kardinalität: 1..1
  * Konformität: reference
* Name:       IKNR
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:       Kundennummer
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Referenz BehandelnderFunktion
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Behandelnde Person
  * Kardinalität: 1..1
  * Konformität: reference
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Priorität
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Kontoverbindung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       BIC
  * Kardinalität: 0..1
  * Konformität: string
* Name:       IBAN
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Kontonummer
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Bankleitzahl
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Referenz Weiterbehandlung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Weiterbehandlung
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Zusätzliche Tarife Code/Bezeichnung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Code
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Krankenversicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Krankenversicherungsverhältnis
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Typ
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Entschädigungen
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Art
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Anzahl
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Einzelpreis
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Faktor
  * Kardinalität: 0..1
  * Konformität: decimal
* Name:       Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Begegnung/Aufenthalt
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Auslagen
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Art
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Anzahl
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Einzelpreis
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Faktor
  * Kardinalität: 0..1
  * Konformität: decimal
* Name:       Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Begegnung/Aufenthalt
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Sonstiges Honorar
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Beschreibung
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Anzahl
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Einzelpreis
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Faktor
  * Kardinalität: 0..1
  * Konformität: decimal
* Name:       Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Begegnung/Aufenthalt
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Zahlungszusatzinformationen
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Direktzahlungsbetrag
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Nachlass
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Minderungssatz
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:     Mahnung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Mahndatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:       Mahnstufe
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Mahngebühr
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Zahldatum
  * Kardinalität: 0..1
  * Konformität: date
* Name:       Zahlbetrag
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:     Rechnungsempfänger
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Kontaktperson
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Patient:in
  * Kardinalität: 0..1
  * Konformität: reference
* Name:   BG-Abrechnung
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Rechnungsnummer
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Nummer
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Nutzung
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Rechnungsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Rechnungsempfänger
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Einrichtung/Organisationseinheit
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       IKNR
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:     Rechnungsersteller
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       IKNR
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:     Priorität
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Referenz Weiterbehandlung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Weiterbehandlung
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Krankenversicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Krankenversicherungsverhältnis
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Typ
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Auslagen
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Beschreibung
  * Kardinalität: 1..1
  * Konformität: string
* Name:       Art
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Anzahl
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Einzelpreis
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Faktor
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Begegnung/Aufenthalt
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Besondere Kosten
  * Kardinalität: 0..*
  * Konformität: 
* Name:       Bezeichnung
  * Kardinalität: 1..1
  * Konformität: string
* Name:       Anzahl
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Einzelpreis
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Faktor
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Begegnung/Aufenthalt
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Mahnung
  * Kardinalität: 0..*
  * Konformität: 
* Name:       Mahndatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:       Mahnstufe
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Mahngebühr
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Zahldatum
  * Kardinalität: 0..1
  * Konformität: date
* Name:       Zahlbetrag
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:     Unfallbetrieb
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Referenz Unfallbetrieb
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Einrichtung/Organisationseinheit
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Kontaktdaten
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Ort
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Gesamtpreis
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:   Sonstige Abrechnung
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Rechnungsnummer
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Nummer
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Nutzung
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Rechnungsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Rechnungsempfänger
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Einrichtung/Organisationseinheit
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       IKNR
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:     Rechnungsersteller
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       IKNR
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:     Priorität
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Vorläufige Abrechnung
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Referenz Weiterbehandlung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Weiterbehandlung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Unterstützende Informationen
  * Kardinalität: 1..*
  * Konformität: 
* Name:       Korrekturzähler
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Zähler
  * Kardinalität: 1..1
  * Konformität: quantity
* Name:       Rechnungsinformation
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Wert
  * Kardinalität: 1..1
  * Konformität: string
* Name:       Ringversuchszertifikat
  * Kardinalität: 0..*
  * Konformität: 
* Name:         Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Referenz Ringversuchszertifikat
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Ringversuchszertifikat
  * Kardinalität: 1..1
  * Konformität: reference
* Name:       Leistungsgenehmigung
  * Kardinalität: 0..*
  * Konformität: 
* Name:         Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Referenz Leistungsgenehmigungen
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Leistung_Psychotherapie
  * Kardinalität: 0..1
  * Konformität: reference
* Name:           Leistung_Heilmittel
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Vertragskennzeichen
  * Kardinalität: 0..*
  * Konformität: 
* Name:         Kategorie
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Kennzeichen
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Mahnung
  * Kardinalität: 0..*
  * Konformität: 
* Name:       Mahndatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:       Mahnstufe
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Mahngebühr
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:       Zahldatum
  * Kardinalität: 0..1
  * Konformität: date
* Name:       Zahlbetrag
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:     Krankenversicherung
  * Kardinalität: 1..*
  * Konformität: 
* Name:       Krankenversicherungsverhältnis
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Vertragkennzeichen
  * Kardinalität: 0..1
  * Konformität: string
* Name:   Weiterbehandlung
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Absicht
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Verweisdatum
  * Kardinalität: 0..1
  * Konformität: datetime
* Name:     Referenz Angeforderter Behandelnder/Einrichtung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Betriebsstätte
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Einrichtung/Organisationseinheit
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Referenz Überweisende Behandelnde Person / Überweisende Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Behandelnde Person
  * Kardinalität: 0..1
  * Konformität: reference
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:   Ringversuchszertifikat
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Hersteller
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Zeitraum
  * Kardinalität: 1..1
  * Konformität: 
* Name:       von
  * Kardinalität: 1..1
  * Konformität: date
* Name:       bis
  * Kardinalität: 0..1
  * Konformität: date
* Name:     Gerätetyp
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Zertifikatsinformation
  * Kardinalität: 0..1
  * Konformität: code
* Name:     Zertifikatskennzeichen
  * Kardinalität: 0..1
  * Konformität: code
* Name:     Analyt-ID
  * Kardinalität: 0..1
  * Konformität: string
* Name:   Genetische Untersuchung
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Datum
  * Kardinalität: 0..1
  * Konformität: datetime
* Name:     Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Gen Code / Bezeichung - Auswahl
  * Kardinalität: 1..*
  * Konformität: 
* Name:       OMIM-G
  * Kardinalität: 0..1
  * Konformität: code
* Name:       OMIM-P
  * Kardinalität: 0..1
  * Konformität: code
* Name:       HGNC-Gen-Symbol
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: string
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Begegnung/Aufenthalt
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Grund
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Grund (OMIM-P-Code)
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Grund (Text)
  * Kardinalität: 0..1
  * Konformität: string
* Name:   Allgemeine Ambulante Operation
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Dokumentationsdatum
  * Kardinalität: 0..1
  * Konformität: datetime
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Kategorie - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Code-Auswahl
  * Kardinalität: 1..*
  * Konformität: 
* Name:         SNOMED CT®-Code
  * Kardinalität: 0..*
  * Konformität: code
* Name:         Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Prozedur - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Code-Auswahl
  * Kardinalität: 1..*
  * Konformität: 
* Name:         OPS-Code
  * Kardinalität: 1..1
  * Konformität: code
* Name:         SNOMED CT®-Code
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Seitenlokalisation
  * Kardinalität: 0..1
  * Konformität: code
* Name:     Referenz Prozedur
  * Kardinalität: 0..1
  * Konformität: 
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Begegnung/Aufenthalt
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Datum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Grund
  * Kardinalität: 0..*
  * Konformität: 
* Name:       GOPs
  * Kardinalität: 0..1
  * Konformität: 
* Name:         bmae
  * Kardinalität: 0..1
  * Konformität: code
* Name:         e-go
  * Kardinalität: 0..1
  * Konformität: code
* Name:         ebm
  * Kardinalität: 0..1
  * Konformität: code
* Name:         goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:         uv-goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:         hzv_selektiv
  * Kardinalität: 0..1
  * Konformität: code
* Name:         sonstige_GOP
  * Kardinalität: 0..1
  * Konformität: code
* Name:     Komplikationsbeschreibung
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Beschreibung
  * Kardinalität: 1..1
  * Konformität: string
* Name:     Gesamtzeit
  * Kardinalität: 0..1
  * Konformität: quantity
* Name:   Ambulante Operation
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Dokumentationsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Kategorie - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Code-Auswahl
  * Kardinalität: 1..*
  * Konformität: 
* Name:         SNOMED CT®-Code
  * Kardinalität: 0..*
  * Konformität: code
* Name:         Ressourcentyp
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Prozedur - Code/Bezeichnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Code-Auswahl
  * Kardinalität: 1..*
  * Konformität: 
* Name:         OPS-Code
  * Kardinalität: 1..1
  * Konformität: code
* Name:         SNOMED CT®-Code
  * Kardinalität: 0..1
  * Konformität: code
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Referenz Prozedur
  * Kardinalität: 0..1
  * Konformität: 
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Referenz Allgemeine Ambulanten Operation
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Allgemeine Ambulante Operation
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Datum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Grund
  * Kardinalität: 0..*
  * Konformität: 
* Name:       GOPs
  * Kardinalität: 0..1
  * Konformität: 
* Name:         bmae
  * Kardinalität: 0..1
  * Konformität: code
* Name:         e-go
  * Kardinalität: 0..1
  * Konformität: code
* Name:         ebm
  * Kardinalität: 0..1
  * Konformität: code
* Name:         goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:         uv-goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:         hzv_selektiv
  * Kardinalität: 0..1
  * Konformität: code
* Name:         sonstige_GOP
  * Kardinalität: 0..1
  * Konformität: code
* Name:     Komplikationsbeschreibung
  * Kardinalität: 1..1
  * Konformität: string
* Name:   Leistung_Psychotherapie
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Zweck
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Versicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       IK-Nummer
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Referenz Organisation
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Einrichtung/Organisationseinheit
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Anfrage
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Behandlungsart
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Antragsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Genehmigung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Bewilligungsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:       Ergebnis
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Referenz Genehmigungsanfrage
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Anfrage
  * Kardinalität: 1..1
  * Konformität: reference
* Name:       Versicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Leistungsinformationen
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Leistung vor dem 1.04.2017
  * Kardinalität: 1..1
  * Konformität: text
* Name:           GOPs
  * Kardinalität: 0..1
  * Konformität: 
* Name:             bmae
  * Kardinalität: 0..1
  * Konformität: code
* Name:             e-go
  * Kardinalität: 0..1
  * Konformität: code
* Name:             ebm
  * Kardinalität: 0..1
  * Konformität: code
* Name:             goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:             uv-goae
  * Kardinalität: 0..1
  * Konformität: code
* Name:             hzv_selektiv
  * Kardinalität: 0..1
  * Konformität: code
* Name:             sonstige_GOP
  * Kardinalität: 0..1
  * Konformität: code
* Name:         Referenz Krankenversicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Krankenversicherungsverhältnis
  * Kardinalität: 1..1
  * Konformität: reference
* Name:         Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Personenbezug
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Bewilligte Leistungen
  * Kardinalität: 0..1
  * Konformität: 
* Name:           Gesamtanzahl
  * Kardinalität: 0..1
  * Konformität: decimal
* Name:   Leistung_Heilmittel
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Zweck
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Patient
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Versicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       IK-Nummer
  * Kardinalität: 0..1
  * Konformität: identifier
* Name:       Bezeichnung
  * Kardinalität: 0..1
  * Konformität: string
* Name:       Referenz Organisation
  * Kardinalität: 0..1
  * Konformität: 
* Name:         Einrichtung/Organisationseinheit
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Anfrage
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Antragsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:     Genehmigung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Bewilligungsdatum
  * Kardinalität: 1..1
  * Konformität: datetime
* Name:       Ergebnis
  * Kardinalität: 1..1
  * Konformität: code
* Name:       Referenz Genehmigungsanfrage
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Anfrage
  * Kardinalität: 1..1
  * Konformität: reference
* Name:       Versicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:         Genehmigungsdiagnose
  * Kardinalität: 1..*
  * Konformität: 
* Name:           ICD-10-GM-Code
  * Kardinalität: 1..1
  * Konformität: 
* Name:             Diagnosecode
  * Kardinalität: 1..1
  * Konformität: code
* Name:             Codierungskennzeichen
  * Kardinalität: 0..1
  * Konformität: code
* Name:             ICD-Diagnosesicherheit
  * Kardinalität: 0..1
  * Konformität: code
* Name:             ICD-Seitenlokalisation
  * Kardinalität: 1..1
  * Konformität: code
* Name:           Diagnosegruppe
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Referenz Krankenversicherung
  * Kardinalität: 1..1
  * Konformität: 
* Name:           Krankenversicherungsverhältnis
  * Kardinalität: 1..1
  * Konformität: reference
* Name:         Genehmigungszeitraum
  * Kardinalität: 0..1
  * Konformität: 
* Name:           Beginn
  * Kardinalität: 0..1
  * Konformität: datetime
* Name:           Ende
  * Kardinalität: 0..1
  * Konformität: datetime
* Name:         Typ
  * Kardinalität: 1..1
  * Konformität: code
* Name:         Name
  * Kardinalität: 1..1
  * Konformität: string
* Name:         Beschreibung
  * Kardinalität: 1..1
  * Konformität: string
* Name:   Raucherstatus
  * Kardinalität: 0..*
  * Konformität: 
* Name:     Status
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Typ
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Code-Auswahl
  * Kardinalität: 2..2
  * Konformität: 
* Name:         KBV-Code
  * Kardinalität: 1..1
  * Konformität: code
* Name:         LOINC®-Code
  * Kardinalität: 1..1
  * Konformität: code
* Name:     Referenz Behandelnder/Behandelnde Person/Einrichtung
  * Kardinalität: 0..*
  * Konformität: 
* Name:       Behandelnde Person
  * Kardinalität: 1..1
  * Konformität: reference
* Name:       Behandelnde Person/Einrichtung
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Referenz Patient
  * Kardinalität: 0..1
  * Konformität: 
* Name:       Patient:in
  * Kardinalität: 0..1
  * Konformität: reference
* Name:     Referenz Begegnung
  * Kardinalität: 1..1
  * Konformität: 
* Name:       Begegnung/Aufenthalt
  * Kardinalität: 1..1
  * Konformität: reference
* Name:     Aufnahmezeitpunkt
  * Kardinalität: 0..1
  * Konformität: datetime
* Name:     Wert
  * Kardinalität: 1..1
  * Konformität: code

