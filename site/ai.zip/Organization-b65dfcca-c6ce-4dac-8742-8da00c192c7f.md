# b65dfcca-c6ce-4dac-8742-8da00c192c7f - Arbeitsgruppe WeST v1.0.0-kommentierung

Arbeitsgruppe WeST

Version 1.0.0-kommentierung - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **b65dfcca-c6ce-4dac-8742-8da00c192c7f**

## Example Organization: b65dfcca-c6ce-4dac-8742-8da00c192c7f



## Resource Content

```json
{
  "resourceType" : "Organization",
  "id" : "b65dfcca-c6ce-4dac-8742-8da00c192c7f",
  "meta" : {
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_WEST_Organization|1.0.0-kommentierung"]
  },
  "extension" : [{
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_Base_Additional_Comment",
    "valueString" : "test"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "XX"
      }]
    },
    "system" : "http://fhir.de/sid/arge-ik/iknr",
    "value" : "123456789"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "BSNR"
      }]
    },
    "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_Base_BSNR",
    "value" : "123456789"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "NIIP"
      }]
    },
    "system" : "http://fhir.de/sid/kbv/vknr",
    "value" : "123456789"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
        "code" : "KZVA"
      }]
    },
    "system" : "http://fhir.de/sid/kzbv/kzvabrechnungsnummer",
    "value" : "123456789"
  }],
  "type" : [{
    "coding" : [{
      "system" : "https://fhir.kbv.de/CodeSystem/KBV-CS-WEST-BDT-Betriebsstaettenstatus",
      "version" : "1.0.0-kommentierung",
      "code" : "1",
      "display" : "Arztpraxis"
    }],
    "text" : "test"
  }],
  "name" : "Praxis X",
  "telecom" : [{
    "system" : "phone",
    "value" : "0173555"
  }],
  "address" : [{
    "type" : "both",
    "line" : ["Musterweg 42"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
        "valueString" : "Musterweg"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "42"
      }]
    }],
    "city" : "Berlin",
    "postalCode" : "9132",
    "country" : "D"
  }],
  "partOf" : {
    "reference" : "urn:uuid:c2aaa336-e17e-491c-bf24-084d4c88309b"
  },
  "contact" : [{
    "purpose" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/contactentity-type",
        "code" : "PAYOR",
        "display" : "Payor"
      }]
    },
    "name" : {
      "use" : "official",
      "family" : "Hans",
      "given" : ["Pater"]
    },
    "telecom" : [{
      "system" : "phone",
      "value" : "12123455"
    }],
    "address" : {
      "text" : "Oberweg 70,12015,Berlin"
    }
  }]
}

```
