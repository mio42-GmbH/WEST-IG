# 4391d2b4-a2be-4c19-a3a6-0d799bb1427e - Arbeitsgruppe WeST v1.0.0-kommentierung

Arbeitsgruppe WeST

Version 1.0.0-kommentierung - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **4391d2b4-a2be-4c19-a3a6-0d799bb1427e**

## Example Observation: 4391d2b4-a2be-4c19-a3a6-0d799bb1427e



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "4391d2b4-a2be-4c19-a3a6-0d799bb1427e",
  "meta" : {
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_WEST_Observation_Body_Temperature|1.0.0-kommentierung"]
  },
  "status" : "amended",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "version" : "2.81",
      "code" : "8310-5",
      "display" : "Körpertemperatur"
    },
    {
      "system" : "http://snomed.info/sct",
      "version" : "http://snomed.info/sct/11000274103/version/20250515",
      "code" : "386725007",
      "display" : "Körpertemperatur"
    }]
  },
  "subject" : {
    "reference" : "Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d"
  },
  "effectiveDateTime" : "2020-01-02",
  "valueQuantity" : {
    "value" : 40,
    "unit" : "degree Celsius",
    "system" : "http://unitsofmeasure.org",
    "code" : "Cel"
  }
}

```
