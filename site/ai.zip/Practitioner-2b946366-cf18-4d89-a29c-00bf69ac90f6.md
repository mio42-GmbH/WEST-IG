# 2b946366-cf18-4d89-a29c-00bf69ac90f6 - Arbeitsgruppe WeST v1.0.0-kommentierung

Arbeitsgruppe WeST

Version 1.0.0-kommentierung - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **2b946366-cf18-4d89-a29c-00bf69ac90f6**

## Example Practitioner: 2b946366-cf18-4d89-a29c-00bf69ac90f6



## Resource Content

```json
{
  "resourceType" : "Practitioner",
  "id" : "2b946366-cf18-4d89-a29c-00bf69ac90f6",
  "meta" : {
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_WEST_Practitioner|1.0.0-kommentierung"]
  },
  "extension" : [{
    "url" : "https://fhir.kbv.de/StructureDefinition/KBV_EX_Base_Additional_Comment",
    "valueString" : "test"
  }],
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "LANR"
      }]
    },
    "system" : "https://fhir.kbv.de/NamingSystem/KBV_NS_Base_ANR",
    "value" : "123456789"
  },
  {
    "type" : {
      "coding" : [{
        "system" : "http://fhir.de/CodeSystem/identifier-type-de-basis",
        "code" : "ZANR"
      }]
    },
    "system" : "http://fhir.de/sid/kzbv/zahnarztnummer",
    "value" : "123456789"
  }],
  "name" : [{
    "use" : "official",
    "text" : "Dr. Hans Glücklich",
    "family" : "Hans",
    "_family" : {
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-name",
        "valueString" : "Glücklich"
      },
      {
        "url" : "http://fhir.de/StructureDefinition/humanname-namenszusatz",
        "valueString" : "Prinz"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/humanname-own-prefix",
        "valueString" : "von"
      }]
    },
    "given" : ["Hans"],
    "prefix" : ["Dr"],
    "_prefix" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-EN-qualifier",
        "valueCode" : "AC"
      }]
    }]
  }],
  "telecom" : [{
    "system" : "phone",
    "value" : "12123455"
  }],
  "address" : [{
    "type" : "both",
    "line" : ["Mittestr 43 Schöneberg"],
    "_line" : [{
      "extension" : [{
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-streetName",
        "valueString" : "Mittestr"
      },
      {
        "url" : "http://hl7.org/fhir/StructureDefinition/iso21090-ADXP-houseNumber",
        "valueString" : "43"
      }]
    }],
    "city" : "Berlin",
    "postalCode" : "12015",
    "country" : "D"
  }],
  "gender" : "other",
  "_gender" : {
    "extension" : [{
      "url" : "http://fhir.de/StructureDefinition/gender-amtlich-de",
      "valueCoding" : {
        "system" : "http://fhir.de/CodeSystem/gender-amtlich-de",
        "code" : "X",
        "display" : "unbestimmt"
      }
    }]
  },
  "birthDate" : "1987-11-11"
}

```
