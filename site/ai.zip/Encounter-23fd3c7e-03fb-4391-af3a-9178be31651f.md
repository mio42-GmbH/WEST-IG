# 23fd3c7e-03fb-4391-af3a-9178be31651f - Arbeitsgruppe WeST v1.0.0-kommentierung

Arbeitsgruppe WeST

Version 1.0.0-kommentierung - ci-build 

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **23fd3c7e-03fb-4391-af3a-9178be31651f**

## Example Encounter: 23fd3c7e-03fb-4391-af3a-9178be31651f



## Resource Content

```json
{
  "resourceType" : "Encounter",
  "id" : "23fd3c7e-03fb-4391-af3a-9178be31651f",
  "meta" : {
    "profile" : ["https://fhir.kbv.de/StructureDefinition/KBV_PR_WEST_Encounter|1.0.0-kommentierung"]
  },
  "status" : "planned",
  "class" : {
    "system" : "http://terminology.hl7.org/CodeSystem/v3-ActCode",
    "code" : "AMB"
  },
  "subject" : {
    "reference" : "Patient/b65dfcca-c6ce-4dac-8742-8da00c192c7d"
  },
  "participant" : [{
    "individual" : {
      "reference" : "urn:uuid:9df81f65-7b3c-410b-b8f1-6426649fcde4"
    }
  }],
  "period" : {
    "start" : "2021-11-15"
  },
  "serviceProvider" : {
    "reference" : "urn:uuid:1e02c811-9ac0-4120-b8b7-58538c6d549f"
  }
}

```
