# Wechselschnittstelle - Startseite - Arbeitsgruppe WeST v1.0.0-kommentierung

Arbeitsgruppe WeST

Version 1.0.0-kommentierung - ci-build 

* [**Table of Contents**](toc.md)
* **Wechselschnittstelle - Startseite**

## Wechselschnittstelle - Startseite

| | |
| :--- | :--- |
| *Official URL*:https://fhir.kbv.de/ImplementationGuide/kbv.mio.west | *Version*:1.0.0-kommentierung |
| Draft as of 2026-06-26 | *Computable Name*:ArbeitsgruppeWeST |

Die mio42 wurde beauftragt eine Wechselschnittstelle nach § 371 Abs. 1 SGB V zu entwickeln, welche dazu dient, Patientendaten bei einem Wechsel des Praxisverwaltungssystems (PVS) sicher, einheitlich und verbindlich zu übertragen. Sie soll durch einen möglichst umfassenden Datentransfer dazu beitragen, bestehende Wechselhürden abzubauen – etwa durch proprietäre Datenformate, Cloud-Hosting, hohe Kosten oder eingeschränkte Usability – und damit echte Systemwahlfreiheit für Arztpraxen ermöglichen. Der Fokus liegt dabei auf einem möglichst holistischen Datenmodell für Interoperabilität und Standardisierung sowie der Sicherstellung einer angemessenen Performanz im Wechselprozess.

Perspektivisch soll die Wechselschnittstelle für die Konzeption einer Mehrwertschnittstelle nachgenutzt werden, um Vorteile während der regulären PVS-Nutzung zu ermöglichen. Die Mehrwertschnittstelle soll dazu dienen, dass weitere Systeme innerhalb einer Praxis standardisiert mit weiteren Systemen der Praxis Daten austauschen kann. Dadurch wird die Wechselschnittstelle ein Absprungpunkt für ein interoperables Ökosystem, in dem Praxen digitale Anwendungen flexibel integrieren und Prozesse effizienter und sicherer gestalten können.

Ziel ist es, Interoperabilität, Datenqualität, Sicherheit und Workflow-Effizienz beim PVS-Wechsel zu erhöhen, Innovationsoffenheit zu fördern, Barrieren und Abhängigkeiten abzubauen und langfristig ein modernes, standardisiertes und patientenorientiertes Gesundheitssystem zu unterstützen.

Essentiell für den Erfolg des Entwicklungsprozesses ist ein praxisnaher und transparenter Austausch mit iterativen Entwicklungsschleifen. Daher entwickelt Mio42 diese Schnittstelle im Co-Creation Ansatz mit der Gematik und der Industrie und in enger Abstimmung mit dem BMG.

Die neue Wechselschnittstelle soll performant und praktikabel werden. Der Interop Council hat dazu innerhalb des Arbeitskreises “Analyse der Effizienz der AWSt” mit relevanten Expert:innen ein Positionspapier entwickelt, in dem konkrete Handlungsempfehlungen für eine optimierte Umsetzung mit FHIR aufgeführt wurden.

#### Wo stehen wir?

Nach dem erfolgreichen Kick-Off der Co-Creation-Phase wurde der Weg für eine enge Zusammenarbeit zwischen allen Beteiligten geebnet. In der Discovery-Phase haben sich Mio42, Gematik und Vertreter der Industrie intensiv mit der Konzeptionierung und Lösungsfindung für die bestehenden Performance- und Praktikabilitätsprobleme der alten Archiv- und Wechselschnittstelle beschäftigt. Gemeinsame Workshops ermöglichten eine detaillierte Analyse der Herausforderungen und legten die Grundlage für die weitere Entwicklung.

Im Fokus stand vor allem die Frage, wie die bestehende Schnittstelle auf Basis des FHIR-Standards weiter optimiert und gleichzeitig praktikabel gestaltet werden kann. Das Format wird nun anhand der Handlungsempfehlungen aus dem Positionspapier des Interop Council kritisch auf die Probe gestellt. Diese Empfehlungen beinhalten unter anderem Ansätze zur Modularisierung der FHIR-Profile und zur Reduzierung von Datenmengen, um die Performance bei großen Datenbeständen zu verbessern.

Die ersten beiden Arbeitspakete des Projekts wurden erstellt und kommentiert. Ziel der ersten Arbeitspakete ist es, eine erste funktionsfähige Implementierung der optimierten Wechselschnittstelle zu entwickeln, die als Grundlage für zukünftige Iterationen und Anpassungen dienen wird.

#### Nächste Schritte

Im weiteren Verlauf des Projekts stehen nun mehrere entscheidende Schritte an, um die Entwicklung der Wechselschnittstelle voranzutreiben und sicherzustellen, dass die optimierte Lösung sowohl technisch als auch praktisch den Anforderungen entspricht.

Anhand der ertsten beiden Arbeitspakete erfolgt eine umfassende Vertestung der Schnittstelle unter Berücksichtigung der Handlungsempfehlungen aus dem Positionspapier des Interop Councils. Diese Testphase wird sicherstellen, dass die entwickelten Lösungen in der Praxis funktionieren und den gewünschten Leistungsanforderungen gerecht werden. Ziel der Tests soll sein, die Performanzverbesserungen für die Wechselschnittstelle zu evaluieren und die Testergebnisse für zukünftige Anpassungen zu nutzen. Dabei wird der weitere Projektverlauf und die Entwicklung der Wechselschnittstelle evaluiert.

Stand Apr 26

